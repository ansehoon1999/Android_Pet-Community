package com.example.android_tesstwo;

public class ConstantDefine {
    public static final int ACT_TAKE_PIC = 1;
    public static final int PERMISSION_CODE = ACT_TAKE_PIC+1;
    public static final int RESULT_OCR = PERMISSION_CODE+1;
}
