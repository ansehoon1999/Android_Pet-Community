# Android-TessTwo
OCR을 이용하여 이미지글자를 인식하여 텍스트로 변환해주는 샘플앱 입니다.
